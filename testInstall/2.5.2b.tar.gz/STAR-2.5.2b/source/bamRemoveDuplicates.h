#ifndef CODE_bamRemoveDuplicates
#define CODE_bamRemoveDuplicates
#include <string>
#include "Parameters.h"

using namespace std;

void bamRemoveDuplicates(const string bamFileName, const string bamFileNameOut, Parameters* const P);

#endif
