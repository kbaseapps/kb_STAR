#ifndef DEF_stringReplaceAll
#define DEF_stringReplaceAll

#include <string>

void stringSubstituteAll(std::string& str, const std::string& from, const std::string& to);

#endif
